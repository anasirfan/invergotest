<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="format-detection" content="telephone=no">
    <title>Digital Infinity Services - Terms & Conditions</title>
    <link href="css/blog_page.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/fav.png" type="image/png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coda:wght@400;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="import" href="https://fonts.googleapis.com/css2?family=Poppins&display=swap">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">    
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <style>
    .content{
        display:block !important;
    }
      @keyframes animate-circle {
      	from {
      		transform: scale(0);
      		opacity: 1;
      	}
      	to {
      		transform: scale(1);
      		opacity: 0;
      	}
      }
      #preloader{
      	width: 100%;
      	height: 100%;
      	position: fixed;
      	top: 0;
      	left: 0;
      	z-index: 999;
      	background: #1C1C1C;
      	background: linear-gradient(to right, rgba(36, 31, 31, 1) 0%, rgba(36, 31, 31, 1) 32%, rgba(74, 71, 70, 1) 100%);
      }
      .loader {
      	position: fixed;
      	top: 50%;
      	left: 50%;
      	height: 10rem;
      	width: 10rem;
      	transform: translateX(-50%) translateY(-50%);
      }
      .loader > .circle {
      	position: absolute;
      	height: inherit;
      	width: inherit;
      	background: #B66449;
      	border-radius: 0;
      	animation: animate-circle 2s cubic-bezier(.9, .24, .62, .79) infinite;
      }
      .loader > .circle:nth-of-type(1) {
      	animation-delay: 0s;
      }
      .loader > .circle:nth-of-type(2) {
      	animation-delay: calc(2s / -3);
      }
      .loader > .circle:nth-of-type(3) {
      	animation-delay: calc(2s / -6);
      }
      .privacyPloicy h3 {
        font-size: 3vh;
    color: #fff;
    font-weight: 600;
    position: relative;
    padding-bottom: 20px;
    text-transform: capitalize;
}
.privacyPloicy p {
    font-size: 16px;
    color: #fff;
    font-weight: 400;
    line-height: 20px;
    margin: 0 auto 25px;
}
.privacy-list {
    margin-top: 20px;
    list-style: disc;
    padding-left: 15px;
}
.privacy-list li {
    font-size: 16px;
    color: #fff;
    font-weight: 400;
    line-height: 20px;
    margin: 0 auto 10px;
}
    </style>
  </head>
  <body>
    <div id="preloader">
      <div class="loader">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
      </div>
    </div>
    <main class="main blog_page">
        <div class="header">
			<div class="button_container" id="toggle"><span class="top"></span><span class="middle"></span><span class="bottom"></span></div>
			<div class="overlay" id="overlay">
				<nav class="overlay-menu">
					<ul>   
                      <li><a href="index">Home</a></li>
						<li><a href="portfolio">view portfolio</a></li>
						<li><a href="packages">view packages</a></li>
						<li><a href="#" class="popup-btn" data-popup="popup-reg">get a quote</a></li>                      
                      	<li><a href="tel:(972) 954-2351">CALL: (972) 954-2351</a></li>
					</ul>
				</nav>
			</div>
			<div class="header__left" >
				<div class="header__letter opac">
					<a href="index"> <img src="img/logo.png" alt="" srcset=""> </a>
				</div>
			</div>
			<div class="header__right">
				<div class="header__btn">
					<div class="btn-container">
						<a href="index">
							<button class="pulse"> <span class="text">GO BACK</span>
								<div class="icon-container">
									<div class="icon icon--left">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
									<div class="icon icon--right">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
								</div>
							</button>
						</a>
					</div>
					<svg style="display: none;">
						<symbol id="arrow-right" viewBox="0 0 20 10">
							<path d="M14.84 0l-1.08 1.06 3.3 3.2H0v1.49h17.05l-3.3 3.2L14.84 10 20 5l-5.16-5z"></path>
						</symbol>
					</svg>
				</div>
			</div>
		</div>      <!--  -->
      <section id="wrapper" class="privacyPloicy">
			<div class="content">
			       <h3>Revision Policy</h3>
                        <p>We practice revision depending upon the package you selected. Customers can ask us for unlimited free revisions and we will revise their design without any additional charges provided that the design and concept remains the same. 48 hours would be Revision Turnaround Time.</p>

                        
                        <h3>Refund Policy / Money Back Guarantee</h3>
                        <p>In any event, any deposited funds for a project shall not be subject to refund after delivery if the initial design concepts are approved, or a change is requested unless Digital Infinity Services™ cancels or terminates your Contract for a reason other than your breach or non-performance.</p>

                        <h3>All refund requests are to be fulfilled as stated:</h3>
                        <ul class="privacy-list">
                            <li class="first">You make a request when the initial concepts for a logo are offered. However once you approve or request changes in the initial designs, the refund offer becomes void and refund request will not be entertained.</li>
                            <li>If request for refund is made before the delivery of initial design concepts, then you would be eligible for Full Refund (less 10% service &amp; processing fee).</li>
                            <li>If request for refund is made within 48 hours, you would be eligible for 66% refund (less 10% service &amp; processing fee)</li>
                            <li>If request for refund is made between 48- 120 hours of the initial design delivery, you would be eligible 33% refund (less 10% service &amp; processing fee).</li>
                            <li>No refund request will be entertained after 120 hours of your initial design delivery, however since we believe in 100% customer satisfaction you`re encouraged to contact us in case of any concern</li>
                            <li>No refund request will be entertained if you have not taken any action on your order for 30 days after placing your order. However, if you want to reactivate your design order, you will be charged a certain fee depending on your project</li>
                            <li>No refund requests will be entertained after the final files have been delivered.</li>
                            <li>For website packages no refund will be entertained once website development has been completed or once the website has been deployed live.</li>
                            <li>For video animation packages no refund request will be entertained after the designing of the storyboard</li>
                            <li>All refund requests should be communicated to the support department. Digital Infinity Services, based on the violation of your user agreement reserves the right to approve/disapprove your request on an individual case to case basis.</li>
                            <li>For Digital Infinity Services / Custom packages, refund will be applicable the same as it is on the single packages.</li>
                            <li>For example, if you order logo and web design service and approve the logo, you can claim refund for the website service at the time of initial design only</li>
                            <li>A refund request will need to have a valid reason which must be qualified against the design brief and customer feedback for revisions. Unless a concept has not been designed according to the brief, a refund will not be given however further revisions will be provided until complete satisfaction.</li>
                            <li>We do not issue out refunds, if you change your mind about a purchase.</li>
                            <li>Money back guarantee is based on that the order is placed in good faith. Where a customer has placed design orders with more than one design agency for the same job with the intention to claim refund, we do not consider it a good faith. In such a case we reserve the right to decline a refund request.</li>
                            <li>All design jobs require customer feedback before finalizing the design therefore it is only fair that the customer gets involved and provides feedback in order to get the desired results.</li>
                            <li>100% unique design guarantee entitles you to a re-draw if our designed logo is to be found considerably similar to another logo design that may already exist. Any resemblance to an existing design will be merely a coincidence and Digital Infinity Services will not accept any responsibility or claim of any compensation in such a case. It is the client's responsibility to get their art work copyrighted.</li>
                            <li>Suppose an individual, entity, or company gets into permanent or temporary closure or hold of business activity. In that case, the amount paid or received to SEO and social media is not refundable. </li>
                            <li>Website design and development require extensive resources and consume our time and internal expenses. Thus, once payment is deposited, it becomes non-refundable no matter how long the project was.</li>
                            <li>SEO and social media marketing payments are non-refundable, and there are no exceptions to our refund policy or money-back guarantees.</li>
                            <li>There is no <b>Refund for Content Writing Packages.</b></li>
                            <li>Patent and trademark fees that have been paid generally cannot be refunded, and the payment method that was used cannot be changed afterwards. In very limited situations, a refund of fees paid may be allowed if the filling has not been completed</li>
                            <li>There are no refunds for any legal paperwork services provided</li>
                            <li class="last"> "If the client remains unresponsive or fails to actively participate in the project for more than 30 days, we reserve the right to consider the project suspended. This would require us to initiate the necessary steps to stop the project and may result in additional reactivation fees."  </li>

                        </ul>
                        


                        <h3>How to claim your refund</h3>
                        <p>To assure your refund request is approved, please make sure you meet the following requirements.</p>
                        <ul class="privacy-list">
                            <li class="first">
                                Claim your refund specifying your concern by contacting us via any of the following three modes:
                            </li>
                            <li>
                                <a href="tel:+(972) 954-2351">Toll free # (972) 954-2351</a>
                            </li>
                            <li>
                                <a onclick="$zopim.livechat.window.toggle()">Live Chat</a>
                            </li>
                            <li>
                                <a href="mailto:sales@digitalinfinityservices.com">sales@digitalinfinityservices.com</a>
                            </li>
                            <li>
                            We will try to resolve your concern by virtue of our revision policy immediately or else will email you a refund request approval from our refund department. After the refund, your design rights would be obtained by Digital Infinity Services and you would not be able to display any version of the design sent by company. Let us also specify that.
                            </li>
                            <li>
                            Since the design rights would now be transferred to the company, you agree that you will have no right (direct or indirect) to use any response or other content, work product or media, nor will you have any ownership interest in or to the same.
                            </li>
                            <li class="last">
                            Working in collaboration with the Government Copyright Agencies Digital Infinity Services would share Copyright Acquisition information for the refunded designs that would restrict the re-use of the designs as original designs in the future. If you have any questions or concerns about our Refund Policy, please contact us by clicking here <a href="mailto:sales@digitalinfinityservices.com">sales@digitalinfinityservices.com</a>.
                            </li>
                        </ul>


                        <h3>My Account</h3>
                        <p>The My Account area is a convenient way to communicate. It is your sole responsibility to check the account area to address any queries, concerns, or additional instructions required by the designer. Not checking or using the Account Area frequently shall not provide you adequate grounds for a refund. However, if you are uncertain how to use the area, you may contact the customer support team at any time for assistance.</p>

                        <h3>Quality Assurance Policy</h3>
                        <p>In order to provide you the desired satisfaction, our designers don't deviate from the specifications provided by you in the order form. The designs are created after a thorough research which ensures the design quality and uniqueness.</p>

                        <h3>100% Satisfaction Guarantee</h3>
                        <p>We rework the ordered design and keep on revising it until you are 100% satisfied (depending upon your package).</p>

                        <h3>Domain and Hosting</h3>
                        <p>Domain and hosting will be provided for free with website packages, where applicable. All the email accounts provided with website packages can be configured on third party email soft-wares such as outlook. Each email account will have 10MB of space.If you are not hosting your website with us, we will not provide email accounts. There is no refund for the hosting, domain or email server package.</p>

                        <h3>Delivery Policy</h3>
                        <p>All design order files are delivered to My Account as per the date specified on the "Order Confirmation". An e-mail is also sent to inform the client about their design order delivery made to their specific account area. All policies pertaining to revision &amp; refund are subject to date and time of design order delivered to client's account area. All design order files are delivered to "My Account" as per the date specified on the "Order Confirmation". An e-mail is also sent to inform the client about their design order delivery made to their specific account area. All policies pertaining to revision &amp; refund are subject to date and time of design order delivered to client's account area. We deliver all our customized design orders via e-mail within 5 to 7 days of receiving your order. We offer a RUSH DELIVERY service through which you can have your first logo samples within 48 hours by paying just $100 extra! For further assistance, contact us at 24-Hour Customer Support Center.</p>

                        <h3>Record Maintenance</h3>
                        <p>We keep a record of your finalized design once we provide you the final files. If you require the final files again in the future we can send them to you at your request.</p>
                        
                        <h3>Customer Support</h3>
                        <p>We offer 24-Hour Customer Support to address your queries and questions. You can contact us any time and we guarantee to respond immediately.</p>

                        <h3>Communication Policy</h3>
                        <p>YOU agree that Digital Infinity Services is not liable for any correspondence from email address (es) other than the ones followed by our own domain i.e. "..@digitalinfinityservices.com" or/and any toll free number that is not mentioned on our website. Digital Infinity Services should not be held responsible for any damage(s) caused by such correspondence. We only take responsibility of any communication through email address (es) under our own domain name or/and via toll free number i.e. already mentioned on Digital Infinity Services Website.</p>

                        <h3>Access to Information</h3>
                        <p>To access Digital Infinity Services services you may be asked to provide certain registration details or other information. By accepting these terms &amp; conditions, you hereby acknowledge that all the information provided by you will be correct, current, and complete. If Digital Infinity Services believes the information that you have provided is not correct, current, or complete, Digital Infinity Services has the right to refuse your access to any services or any of its resources, and to terminate or suspend your account at any time. Digital Infinity Services is operating under a PCI DSS compliant company; therefore it is authorized to keep your credit card information on file that can be used for any recurring service, additional development hours, server or network equipment required to develop or launch your website without any prior notification. However, our representatives always bring this in knowledge so that you are aware about all the processes.</p>

                        <h3>100% Unique Design Guarantee</h3>
                        <p>At Digital Infinity Services we guarantee that all of our customers' logos are made from scratch. This way you will have a logo that is tailor made for your requirements. We guarantee that your logo will be unique and impress your clientele.</p>

                        <h3>Prohibitions</h3>
                        <p>The Company will assist the Client with the integration of 3rd party plugins and APIs but any third party integration required to assist with the functionality of the website will be STRICTLY standard. The Company will not have anything to do with any third party dealings during the development of this project. All additional work will require a separate fee agreement.</p>

		    </div>
    </section>
      <script type="text/javascript" src="script.js"></script>
      <!--  -->
        <footer>
      <div id="popup-reg" class="popup">
  <div class="popup-content">
    <div class="event-header">
      <h6>Don't be shy, say hi!</h6>
    </div>
      <form id="send" class="send-form">
        <div class="form-group">
          <input type="text" placeholder="Enter full name" id="name" name="name" required="required">
          <label for="name">
            <i class="fa fa-user"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="tel" placeholder="Enter your phone #" id="phone" name="phone" required="required">
          <label for="phone">
            <i class="fa fa-phone"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="email" placeholder="Enter your email" id="mail" name="mail" required="required">
          <label for="mail">
            <i class="fa fa-envelope"></i>
          </label>
        </div>
        <div class="form-group">
          <textarea placeholder="How can we help?" name="text" id="text"></textarea>
          <label for="text" class="txt">
            <i class="fa fa-commenting"></i>
          </label>
        </div>
        <button type="submit" class="main-btn-rect" name="text" value="Send">
          <i class="fa fa-paper-plane"></i>Send</button>
      </form>
    <span class="fade-out main-btn-circle">x</span>
  </div>
</div>      <div class="ftup d-flex al-center">
        <div class="ftlogo"><img src="img/logo.png" alt=""></div>
        <div class="ftup2 popup-btn" data-popup="popup-reg"><button>GET A QUOTE</button></div>
      </div>
      <div class="ftmid d-flex pd-60">
        <div class="ftmenu">
          <p>Quick Links</p>
          <ul>            
            <li><a href="portfolio.php">Portfolio</a></li>            
            <li><a href="mailto:info@digitalinfinityservices.com">Contact Us</a></li>
            <li><a href="tel:(972) 954-2351">Call Now!</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Helpful Links</p>
          <ul>
            <li><a href="privacy.php">Privacy Policy</a></li>
            <li><a href="terms.php">Terms & Conditions</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Our Socials</p>
          <ul>
            <li><a href="https://www.facebook.com/people/Digital-Infinity-Services/100090365663506/">Facebook</a></li>
            <li><a href="https://www.instagram.com/digitalinfinityservices/">Insta</a></li>
          </ul>
        </div>
      </div>
      <div class="ftend d-flex al-center">
          <div class="ftcopyr"><p>Copyright © 2023 <span>Digital Infinity Services</span>. All Rights Reserved.</p></div>
      </div>
    </footer>    </main>
    <script src="js/main.js"></script>
    <script>
      // menu
$('#toggle').click(function() {
    $(this).toggleClass('active');
    $('#overlay').toggleClass('open');
   });
   jQuery(function($) {

var html = $('html');
var viewport = $(window);
var viewportHeight = viewport.height();

var scrollMenu = $('#section-menu');
var timeout = null;

function menuFreeze() {
  if (timeout !== null) {
    scrollMenu.removeClass('freeze');
    clearTimeout(timeout);
  }

  timeout = setTimeout(function() {
    scrollMenu.addClass('freeze');
  }, 2000);
}
scrollMenu.mouseover(menuFreeze);

/* ==========================================================================
   Build the Scroll Menu based on Sections .scroll-item
   ========================================================================== */

var sectionsHeight = {},
  viewportheight, i = 0;
var scrollItem = $('.scroll-item');
var bannerHeight;

function sectionListen() {
  viewportHeight = viewport.height();
  bannerHeight = (viewportHeight);
  $('.section').addClass('resize');
  scrollItem.each(function() {
    sectionsHeight[this.title] = $(this).offset().top;
  });
}
sectionListen();
viewport.resize(sectionListen);
viewport.bind('orientationchange', function() {
  sectionListen();
});

var count = 0;

scrollItem.each(function() {
  var anchor = $(this).attr('id');
  var title = $(this).attr('title');
  count++;
  $('#section-menu ul').append('<li><a id="nav_' + title + '" href="#' + anchor + '"><span>' + count + '</span> ' + title + '</a></li>');
});

function menuListen() {
  var pos = $(this).scrollTop();
  pos = pos + viewportHeight * 0.625;
  for (i in sectionsHeight) {
    if (sectionsHeight[i] < pos) {
      $('#section-menu a').removeClass('active');
      $('#section-menu a#nav_' + i).addClass('active');;
      var newHash = '#' + $('.scroll-item[title="' + i + '"]').attr('id');
      if (history.pushState) {
        history.pushState(null, null, newHash);
      } else {
        location.hash = newHash;
      }
    } else {
      $('#section-menu a#nav_' + i).removeClass('active');
      if (pos < viewportHeight - 72) {
        history.pushState(null, null, ' ');
      }
    }
  }
}
scrollMenu.css('margin-top', scrollMenu.height() / 2 * -1);

/* ==========================================================================
   Smooth Scroll for Anchor Links and URL refresh
   ========================================================================== */

scrollMenu.find('a').click(function() {
  var href = $.attr(this, 'href');
  $('html').animate({
    scrollTop: $(href).offset().top
  }, 500, function() {
    window.location.hash = href;
  });
  return false;
});

/* ==========================================================================
   Fire functions on Scroll Event
   ========================================================================== */

function scrollHandler() {
  menuListen();
  menuFreeze();
}
scrollHandler();
viewport.on('scroll', function() {
  scrollHandler();
  //			window.requestAnimationFrame(scrollHandler);
});
});
         $(document).ready(function(){
  $('.popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','0').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 600);
      });
 });
});
    </script>
  </body>
</html>