<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="format-detection" content="telephone=no">
    <title>Digital Infinity Services - Privacy Policy</title>
    <link href="css/blog_page.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/fav.png" type="image/png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coda:wght@400;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="import" href="https://fonts.googleapis.com/css2?family=Poppins&display=swap">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">    
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <style>
    .content{
        display:block !important;
    }
      @keyframes animate-circle {
      	from {
      		transform: scale(0);
      		opacity: 1;
      	}
      	to {
      		transform: scale(1);
      		opacity: 0;
      	}
      }
      #preloader{
      	width: 100%;
      	height: 100%;
      	position: fixed;
      	top: 0;
      	left: 0;
      	z-index: 999;
      	background: #1C1C1C;
      	background: linear-gradient(to right, rgba(36, 31, 31, 1) 0%, rgba(36, 31, 31, 1) 32%, rgba(74, 71, 70, 1) 100%);
      }
      .loader {
      	position: fixed;
      	top: 50%;
      	left: 50%;
      	height: 10rem;
      	width: 10rem;
      	transform: translateX(-50%) translateY(-50%);
      }
      .loader > .circle {
      	position: absolute;
      	height: inherit;
      	width: inherit;
      	background: #B66449;
      	border-radius: 0;
      	animation: animate-circle 2s cubic-bezier(.9, .24, .62, .79) infinite;
      }
      .loader > .circle:nth-of-type(1) {
      	animation-delay: 0s;
      }
      .loader > .circle:nth-of-type(2) {
      	animation-delay: calc(2s / -3);
      }
      .loader > .circle:nth-of-type(3) {
      	animation-delay: calc(2s / -6);
      }
      .privacyPloicy h3 {
        font-size: 3vh;
    color: #fff;
    font-weight: 600;
    position: relative;
    padding-bottom: 20px;
    text-transform: capitalize;
}
.privacyPloicy p {
    font-size: 16px;
    color: #fff;
    font-weight: 400;
    line-height: 20px;
    margin: 0 auto 25px;
}
.privacy-list {
    margin-top: 20px;
    list-style: disc;
    padding-left: 15px;
}
.privacy-list li {
    font-size: 16px;
    color: #fff;
    font-weight: 400;
    line-height: 20px;
    margin: 0 auto 10px;
}
    </style>
  </head>
  <body>
    <div id="preloader">
      <div class="loader">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
      </div>
    </div>
    <main class="main blog_page">
        <div class="header">
			<div class="button_container" id="toggle"><span class="top"></span><span class="middle"></span><span class="bottom"></span></div>
			<div class="overlay" id="overlay">
				<nav class="overlay-menu">
					<ul>   
                      <li><a href="index">Home</a></li>
						<li><a href="portfolio">view portfolio</a></li>
						<li><a href="packages">view packages</a></li>
						<li><a href="#" class="popup-btn" data-popup="popup-reg">get a quote</a></li>                      
                      	<li><a href="tel:(972) 954-2351">CALL: (972) 954-2351</a></li>
					</ul>
				</nav>
			</div>
			<div class="header__left" >
				<div class="header__letter opac">
					<a href="index"> <img src="img/logo.png" alt="" srcset=""> </a>
				</div>
			</div>
			<div class="header__right">
				<div class="header__btn">
					<div class="btn-container">
						<a href="index">
							<button class="pulse"> <span class="text">GO BACK</span>
								<div class="icon-container">
									<div class="icon icon--left">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
									<div class="icon icon--right">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
								</div>
							</button>
						</a>
					</div>
					<svg style="display: none;">
						<symbol id="arrow-right" viewBox="0 0 20 10">
							<path d="M14.84 0l-1.08 1.06 3.3 3.2H0v1.49h17.05l-3.3 3.2L14.84 10 20 5l-5.16-5z"></path>
						</symbol>
					</svg>
				</div>
			</div>
		</div>      <!--  -->
      <section id="wrapper" class="privacyPloicy">
			<div class="content">
                  <h3>About The Policy</h3>
                        <p>At Digital Infinity Services, our first priority is the privacy of our clients and we respect it as our own. Though we collect information from our clients, it is only used to make improvements in our customer services. Our company acknowledges that the maintenance and use of our clients' information is our responsibility. We DO NOT rent or sell the information that our clients provide us online.</p>
                        <p>This policy pertains to details for the security of data collected of our client, how it is used, why we collect it, and how we use it. Our policy defines all the options and ways you can opt for in regards to your data collection and our use of your information.</p>

                        
                        <h3>Personal Information Collected</h3>
                        <p>The information collected by Digital Infinity Services includes the client's name, e-mail, mailing address and phone number. These are pieces of information that the client provides us while ordering or while saving the information with our company. We may also use the email addresses or mailing addresses which we receive through our mailing system such as our Contact Us Form for responding to comments, queries etc.</p>
                        <p>Our company also maintains records of the items, which have interested our clients in the past, as well as the client's purchases online.</p>

                        <h3>Use of Collected Data</h3>
                        <p>The information collected is used in many diversified methods. Our company uses the information saved by our clients to process their order. We also send them emails to confirm the order and our customer services may also contact them via phone, mailing address or e-mail if our company has other queries regarding the order placed.</p>
                        <p>As a client, one might also receive updates regarding our site and services which may include a newsletter and information on promotions. In addition, we may also use the information about your interests and purchases to help our company improve our site design and the client's purchasing experience.</p>

                        <h3>Newsletter Opt-out</h3>
                        <p>If you no longer wish to receive our newsletter and promotional communications, you may opt-out of receiving them by following the instructions included in each newsletter or communication or by emailing us at Or calling us at <a href="tel:(972) 954-2351">(609) 666-0435</a>.</p>


                        <h3>Social Media (Features) and Widgets</h3>
                        <p>Our Web site includes Social Media Features, such as the Facebook Like button [and Widgets, such as the Share this button or interactive mini-programs that run on our site]. These Features may collect your IP address, which page you are visiting on our site, and may set a cookie to enable the Feature to function properly. Social Media Features and Widgets are either hosted by a third party or hosted directly on our Site. Your interactions with these Features are governed by the privacy policy of the company providing it.</p>

                        <h3>3rd Party Intervene</h3>
                        <p>Personal information will NOT be released to third parties unless as described in this policy. There are no circumstances under Which we sell personal information to third parties.</p>
                        <p>We use credit card processing companies to bill you for services. These companies do not retain, share, store or use personally identifiable information for any other purposes. We also use Live Person to provide live customer support chat on our website. These companies are authorized to use your personal information only as necessary to provide these services to us.</p>

                        <h3>Security of Personal Information</h3>
                        <p>The information of our clients is secure, as it is protected during transmission by the use of the Secure Sockets Layer (SSL) Software which encrypts the information the client puts in. We follow generally accepted industry standards to protect the personal information submitted to us, both during transmission and once we receive it. No method of transmission over the Internet, or method of electronic storage, is 100% secure, however. Therefore, while we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security.</p>
                        <p>If you have any questions about security on our Web site, you can send email us at <a href="mailto:support@digitalinfinityservices.com">support@digitalinfinityservices.com</a></p>

                        <h3>Access of Registered Accounts</h3>
                        <p>The client can access their registered accounts by signing in on our homepage. Once signed in, the client has access to their previous lists and information that they have already submitted to the site. The users are able to update their information once they have logged in to their accounts by clicking My Account.</p>

                        <h3>Changing &amp; Deleting/Unsubscribing Accounts</h3>
                        <p>The client has to send in an email to request the cancellation of subscription or request to have their personal information deleted. This shall prevent the user from receiving emails communication relating to any online order they might have placed at the site.</p>
                        <p>We will retain your information for as long as your account is active or as needed to provide you services. Please contact us if you wish to cancel your account or request that we no longer use your information to provide you services. We will retain and use your information as necessary to comply with our legal obligations, resolve disputes, and enforce our agreements.</p>

                        <h3>Cookies and Their Use</h3>
                        <p>Cookies are alphanumeric identifiers that are transferred to the clients' hard drives through their Web browsers. This enables our systems to recognize the clients' browsers and storage of items in their Shopping Carts during visits.</p>
                        <p>The Help portion of the toolbar on most browsers will be more helpful in explaining how to prevent the browser from accepting new cookies, how to have the browser notify the user when a new cookie is received, or how to disable cookies altogether. However, cookies allow you to take full advantage of the top features at our site, and our company's personal recommendation is that the client leaves them to be accepted.</p>
                        <p>Second, we keep track of your IP address to help diagnose problems with our server and to administer our Web site. Your IP address is also used to gather broad demographic information about you, such as your location and your Internet service provider. We may also collect combined information on how our users are utilizing the site. This might include information regarding traffic patterns through the site and search queries. No IP address/log file information is tied to Personally Identifiable Information (PII).</p>
                        <p>Third, we log browser types, access times, URLs from which visitors came to our site and URLs viewed by visitors while on our site. Except as otherwise stated in this Privacy Policy, we do not provide this information to third parties, except in combined form.</p>
                        <p>The use of cookies by our partners, affiliates, tracking utility company, service providers is not covered by our privacy statement. We do not have access or control over these cookies. Our partners, affiliates, tracking utility company, service providers use session ID cookies to make it easier for you to navigate our site.</p>
                        
                        <h3>Clear Gifs (Web Beacons/Web Bugs)</h3>
                        <p>We employ a software technology called clear gifs (a.k.a. Web Beacons/Web Bugs), that help us better manage content on our site by informing us what content is effective. Clear gifs are tiny graphics with a unique identifier, similar in function to cookies, and are used to track the online movements of Web users. In contrast to cookies, which are stored on a user's computer hard drive, clear gifs are embedded invisibly on Web pages and are about the size of the period at the end of this sentence. We do not tie the information gathered by clear gifs to our customers' personally identifiable information.</p>

                        <h3>Testimonials</h3>
                        <p>With your consent we may post your testimonial along with your name. If you want your testimonial removed please contact us.</p>

                        <h3>Links to Other Web Sites</h3>
                        <p>Our Site includes links to other Web sites whose privacy practices may differ from those of ours. If you submit personal information to any of those sites, your information is governed by their privacy statements. We encourage you to carefully read the privacy statement of any Web site you visit.</p>

                        <h3>Notification of the Changes in Privacy Policy</h3>
                        <p>If we decide to change our privacy policy, we will post those changes to this privacy statement, the homepage, and other places we deem appropriate so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we disclose it. We reserve the right to modify this privacy statement at any time, so please review it frequently. If we make material changes to this policy, we will notify you here, by email, or by means of a notice on our homepage before the change takes effect.</p>

                        <h3>Legal Disclaimer</h3>
                        <p>We reserve the right to disclose your personally identifiable information as required by law and when we believe that disclosure is necessary to protect our rights and/or comply with a judicial proceeding, court order, or legal process served on our Web site.</p>

                        <h3>Questions</h3>
                        <p>We reserve the right to disclose your personally identifiable information as required by law and when we believe that disclosure is necessary to protect our rights and/or comply with a judicial proceeding, court order, or legal process served on our Web site.</p>
                        <p>If you have any questions regarding our Privacy Policy or our use of your information, call our toll free number <a href="tel:(972) 954-2351">(972) 954-2351</a> or email us on <a href="mailto:support@digitalinfinityservices.com">support@digitalinfinityservices.com</a></p>
		    </div>
    </section>
      <script type="text/javascript" src="script.js"></script>
      <!--  -->
        <footer>
      <div id="popup-reg" class="popup">
  <div class="popup-content">
    <div class="event-header">
      <h6>Don't be shy, say hi!</h6>
    </div>
      <form id="send" class="send-form">
        <div class="form-group">
          <input type="text" placeholder="Enter full name" id="name" name="name" required="required">
          <label for="name">
            <i class="fa fa-user"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="tel" placeholder="Enter your phone #" id="phone" name="phone" required="required">
          <label for="phone">
            <i class="fa fa-phone"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="email" placeholder="Enter your email" id="mail" name="mail" required="required">
          <label for="mail">
            <i class="fa fa-envelope"></i>
          </label>
        </div>
        <div class="form-group">
          <textarea placeholder="How can we help?" name="text" id="text"></textarea>
          <label for="text" class="txt">
            <i class="fa fa-commenting"></i>
          </label>
        </div>
        <button type="submit" class="main-btn-rect" name="text" value="Send">
          <i class="fa fa-paper-plane"></i>Send</button>
      </form>
    <span class="fade-out main-btn-circle">x</span>
  </div>
</div>      <div class="ftup d-flex al-center">
        <div class="ftlogo"><img src="img/logo.png" alt=""></div>
        <div class="ftup2 popup-btn" data-popup="popup-reg"><button>GET A QUOTE</button></div>
      </div>
      <div class="ftmid d-flex pd-60">
        <div class="ftmenu">
          <p>Quick Links</p>
          <ul>            
            <li><a href="portfolio.php">Portfolio</a></li>            
            <li><a href="mailto:info@digitalinfinityservices.com">Contact Us</a></li>
            <li><a href="tel:(972) 954-2351">Call Now!</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Helpful Links</p>
          <ul>
            <li><a href="privacy.php">Privacy Policy</a></li>
            <li><a href="terms.php">Terms & Conditions</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Our Socials</p>
          <ul>
            <li><a href="https://www.facebook.com/people/Digital-Infinity-Services/100090365663506/">Facebook</a></li>
            <li><a href="https://www.instagram.com/digitalinfinityservices/">Insta</a></li>
          </ul>
        </div>
      </div>
      <div class="ftend d-flex al-center">
          <div class="ftcopyr"><p>Copyright © 2023 <span>Digital Infinity Services</span>. All Rights Reserved.</p></div>
      </div>
    </footer>    </main>
    <script src="js/main.js"></script>
    <script>
      // menu
$('#toggle').click(function() {
    $(this).toggleClass('active');
    $('#overlay').toggleClass('open');
   });
   jQuery(function($) {

var html = $('html');
var viewport = $(window);
var viewportHeight = viewport.height();

var scrollMenu = $('#section-menu');
var timeout = null;

function menuFreeze() {
  if (timeout !== null) {
    scrollMenu.removeClass('freeze');
    clearTimeout(timeout);
  }

  timeout = setTimeout(function() {
    scrollMenu.addClass('freeze');
  }, 2000);
}
scrollMenu.mouseover(menuFreeze);

/* ==========================================================================
   Build the Scroll Menu based on Sections .scroll-item
   ========================================================================== */

var sectionsHeight = {},
  viewportheight, i = 0;
var scrollItem = $('.scroll-item');
var bannerHeight;

function sectionListen() {
  viewportHeight = viewport.height();
  bannerHeight = (viewportHeight);
  $('.section').addClass('resize');
  scrollItem.each(function() {
    sectionsHeight[this.title] = $(this).offset().top;
  });
}
sectionListen();
viewport.resize(sectionListen);
viewport.bind('orientationchange', function() {
  sectionListen();
});

var count = 0;

scrollItem.each(function() {
  var anchor = $(this).attr('id');
  var title = $(this).attr('title');
  count++;
  $('#section-menu ul').append('<li><a id="nav_' + title + '" href="#' + anchor + '"><span>' + count + '</span> ' + title + '</a></li>');
});

function menuListen() {
  var pos = $(this).scrollTop();
  pos = pos + viewportHeight * 0.625;
  for (i in sectionsHeight) {
    if (sectionsHeight[i] < pos) {
      $('#section-menu a').removeClass('active');
      $('#section-menu a#nav_' + i).addClass('active');;
      var newHash = '#' + $('.scroll-item[title="' + i + '"]').attr('id');
      if (history.pushState) {
        history.pushState(null, null, newHash);
      } else {
        location.hash = newHash;
      }
    } else {
      $('#section-menu a#nav_' + i).removeClass('active');
      if (pos < viewportHeight - 72) {
        history.pushState(null, null, ' ');
      }
    }
  }
}
scrollMenu.css('margin-top', scrollMenu.height() / 2 * -1);

/* ==========================================================================
   Smooth Scroll for Anchor Links and URL refresh
   ========================================================================== */

scrollMenu.find('a').click(function() {
  var href = $.attr(this, 'href');
  $('html').animate({
    scrollTop: $(href).offset().top
  }, 500, function() {
    window.location.hash = href;
  });
  return false;
});

/* ==========================================================================
   Fire functions on Scroll Event
   ========================================================================== */

function scrollHandler() {
  menuListen();
  menuFreeze();
}
scrollHandler();
viewport.on('scroll', function() {
  scrollHandler();
  //			window.requestAnimationFrame(scrollHandler);
});
});
         $(document).ready(function(){
  $('.popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','0').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 600);
      });
 });
});
    </script>
  </body>
</html>