<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="format-detection" content="telephone=no">
	<title>Digital Infinity Services - UI/UX</title>
	<link href="css/blog_page.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link rel="shortcut icon" href="img/fav.png" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Coda:wght@400;800&display=swap" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<link rel="import" href="https://fonts.googleapis.com/css2?family=Poppins&display=swap">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>		
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style>
    .header{
      z-index:1000;
    }
    @media screen and (max-width: 768px){
      .imgboxxx{
        display:none !important;
      }
      .ftSec{
        height:auto !important;
        padding:50px !important;
        margin:0 !important;
      }
      .small p{
        font-size:24px;
      }
      .content__left{
        width:100% !important;
        margin:0 !important;
      }
      .content__right{
        width:100% !important;
        display:none !important;
      }           
  }
	@keyframes animate-circle {
		from {
			transform: scale(0);
			opacity: 1;
		}
		to {
			transform: scale(1);
			opacity: 0;
		}
	}
 
	
	#preloader {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;
		background: #1C1C1C;
		background: linear-gradient(to right, rgba(36, 31, 31, 1) 0%, rgba(36, 31, 31, 1) 32%, rgba(74, 71, 70, 1) 100%);
	}
	
	.loader {
		position: fixed;
		top: 50%;
		left: 50%;
		height: 10rem;
		width: 10rem;
		transform: translateX(-50%) translateY(-50%);
	}
	
	.loader > .circle {
		position: absolute;
		height: inherit;
		width: inherit;
		background: #B66449;
		border-radius: 0;
		animation: animate-circle 2s cubic-bezier(.9, .24, .62, .79) infinite;
	}
	
	.loader > .circle:nth-of-type(1) {
		animation-delay: 0s;
	}
	
	.loader > .circle:nth-of-type(2) {
		animation-delay: calc(2s / -3);
	}
	
	.loader > .circle:nth-of-type(3) {
		animation-delay: calc(2s / -6);
	}
  .inph1{top:35vh !important;right: 90px !important;    height: fit-content;}.inph1 img{width:25vh !important;}
  .inph2{top:20vh !important;right: 30px !important;    height: fit-content;}.inph2 img{width:25vh !important;}
  .inph3{top:50vh !important;right: 5px !important;    height: fit-content;}.inph3 img{width:25vh !important;}
  p{font-size:2.5vh;color:#fff;    font-family: 'Coda';}
  button {
    --width: 170px;
  }
  .mtb-20{
    margin:20px 0;
  }
  .h1{
    line-height: 1.15;
    color:#fff;
    font-family: Helena Display;
  }
  .fas{
    color: #ff7e00;
  }
  .form-connect {
	padding: 120px 0!important;
	background: linear-gradient(90deg,#12395a 0,#ca73b9 71%,#ca73b9 100%);
	position: relative;
}

.color-white {
	color: #fff!important;
}

.form-connect .form-group input,.form-connect .form-group select,.form-connect .form-group textarea {
	color: #fff!important;
}
.container-fluid {max-width: 1630px;margin: 0 auto;padding: 0 45px;}



	</style>
</head>

<body>
	<!-- <div id="preloader">
		<div class="loader">
			<div class="circle"></div>
			<div class="circle"></div>
			<div class="circle"></div>
		</div>
	</div> -->
	<main class="main">
    <!-- Back to top button -->
    <a id="topbutton"></a>
		<div class="header">
			<div class="button_container" id="toggle"><span class="top"></span><span class="middle"></span><span class="bottom"></span></div>
			<div class="overlay" id="overlay">
				<nav class="overlay-menu">
					<ul>   
                      <li><a href="index">Home</a></li>
						<li><a href="portfolio">view portfolio</a></li>
						<li><a href="packages">view packages</a></li>
						<li><a href="#" class="popup-btn" data-popup="popup-reg">get a quote</a></li>                      
                      	<li><a href="tel:(972) 954-2351">CALL: (972) 954-2351</a></li>
					</ul>
				</nav>
			</div>
			<div class="header__left" >
				<div class="header__letter opac">
					<a href="index"> <img src="img/logo.png" alt="" srcset=""> </a>
				</div>
			</div>
			<div class="header__right">
				<div class="header__btn">
					<div class="btn-container">
						<a href="index">
							<button class="pulse"> <span class="text">GO BACK</span>
								<div class="icon-container">
									<div class="icon icon--left">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
									<div class="icon icon--right">
										<svg style="rotate: 180deg;">
											<use xlink:href="#arrow-right"></use>
										</svg>
									</div>
								</div>
							</button>
						</a>
					</div>
					<svg style="display: none;">
						<symbol id="arrow-right" viewBox="0 0 20 10">
							<path d="M14.84 0l-1.08 1.06 3.3 3.2H0v1.49h17.05l-3.3 3.2L14.84 10 20 5l-5.16-5z"></path>
						</symbol>
					</svg>
				</div>
			</div>
		</div>		<!--  -->
		<section id="wrapper" style="background:#000">
      <div class="content ftSec">
          <div class="content__left"style="width:60%;margin:0 150px;">
            <div class="content__title">
              <div class="h1"><span style="color:#ff7e00;">UI/UX</span></div>
              <p class="mtb-20"><i>UI/UX services refer to designing and developing user interfaces and user experiences for websites and mobile applications. UI/UX services include a range of activities that focus on improving the user experience of a product or service. </i></p>  
              <div class="btn-container" style="justify-content: end !important;">
                <button class="pulse main-btn-rect popup-btn" data-popup="popup-reg" style="background:#ff7e00">
                  <span class="text">Get A Quote</span>
                  <div class="icon-container">
                    <div class="icon icon--left">
                      <svg>
                        <use xlink:href="#arrow-right"></use>
                      </svg>
                    </div>
                    <div class="icon icon--right">
                      <svg>
                        <use xlink:href="#arrow-right"></use>
                      </svg>
                    </div>
                  </div>
                </button>
              </div>            
            </div>
            
          </div>
          <div class="content__right imgboxxx" style="width:40%">
            <div class="inph1 floating"><img class="popout anim-del1" src="images/1.jpg" alt="" srcset=""></div>
            <div class="inph2 floating anim-durb"><img class="popout anim-del2" src="images/4.jpg" alt="" srcset=""></div>
            <div class="inph3 floating anim-durb"><img class="popout anim-del3" src="images/12.jpg" alt="" srcset=""></div>
          </div>
      </div>
		</section>
    <section id="wrapper" class="db">
      <div class="content p-0">
          <div class="content__left"style="width:100%;margin:0 150px;">
            <div class="content__title">
              <div class="h1"><span style="color:#ff7e00;">What do we</span><BR>have to show for it all</div>
              <p class="mtb-20">Our Milestones</p> 
                <!--  -->
                  <div class="ctr">
                    <div class="counter-container">
                        <i class="fas fa-check fa-3x"></i>
                        <div class="counter" data-target="12000"></div>
                        <span>Projects Delivered</span>
                    </div>
                    <div class="counter-container">
                        <i class="fas fa-check fa-3x"></i>
                        <div class="counter" data-target="2000"></div>
                        <span>Total Clientele</span>
                    </div>
                    <div class="counter-container">
                        <i class="fas fa-check fa-3x"></i>
                        <div class="counter" data-target="989"></div>
                        <span>Active Clients</span>
                    </div>
                  </div>
                <!--  -->
            </div>            
          </div>          
      </div>
		</section>
    <section id="wrapper" class="smallstrip">
      <div class="content m-0 p-0">
          <div class="content__left"style="width:100%;margin:0 150px;">
            <div class="content__title" style="text-align:center">
              <div class="h1"><span>Shall We Begin?</span></div>
              <p class="mtb-20">Want to know how we can help your business take off? Get in touch and talk to our experts for all your Designing needs.</p> 
              <div class="btn-container" style="justify-content: center !important;">
                <a href="portfolio.php">
                <button class="pulse" style=" background:#000;">
                  <span class="text">VIEW PORTFOLIO</span>
                  <div class="icon-container">
                    <div class="icon icon--left">
                      <svg>
                        <use xlink:href="#arrow-right"></use>
                      </svg>
                    </div>
                    <div class="icon icon--right">
                      <svg>
                        <use xlink:href="#arrow-right"></use>
                      </svg>
                    </div>
                  </div>
                </button>
                </a>
              </div>  
            </div>            
          </div>          
      </div>
		</section>
    <section id="wrapper" class="db">
      <div class="content p-0">
          <div class="content__left"style="width:100%;">
            <div class="content__title" style="text-align:center">
              <p class="mtb-20">Services we offer:</p>                
            </div>            
			<div class="servBx">
  				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">Interaction design</p><span>This involves creating the structure and layout of the interface, as well as defining how users will interact with it.</span></div>
				</div>
				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">Visual design</p><span>This involves creating the overall look and feel of the interface, including the use of color, typography, and imagery.</span></div>
				</div>
				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">User testing</p><span>This involves testing the interface with users to identify any issues and make improvements.</span></div>
				</div>
			</div>
			<div class="servBx">
  				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">Usability testing</p><span>This involves testing the interface with users to identify any usability issues and make improvements.</span></div>
				</div>
				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">Accessibility testing</p><span>This involves testing the interface with users having disabilities to ensure that everyone can use it.</span></div>
				</div>
				<div>
  					<div><img src="img/star.png" alt="" srcset=""></div>
					<div><p class="mtb-20">Responsive design</p><span>Responsive design involves creating interfaces that adapt to different screen sizes and devices.</span></div>
				</div>
			</div>
          </div>          
      </div>
		</section>
		<section id="wrapper" class="">
      <div class="content p-0">
          <div class="content__left"style="width:100%;">
            <div class="content__title" style="text-align:center">
              <p class="mtb-20">Our professional UI/UX design experts at Digital Finity don't simply offer solutions; they also wrap them in slick, attractive, responsive, and user-friendly designs. </p>                
            </div>            			
          </div>          
      </div>
		</section>


		
		
    <footer>
      <div id="popup-reg" class="popup">
  <div class="popup-content">
    <div class="event-header">
      <h6>Don't be shy, say hi!</h6>
    </div>
      <form id="send" class="send-form">
        <div class="form-group">
          <input type="text" placeholder="Enter full name" id="name" name="name" required="required">
          <label for="name">
            <i class="fa fa-user"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="tel" placeholder="Enter your phone #" id="phone" name="phone" required="required">
          <label for="phone">
            <i class="fa fa-phone"></i>
          </label>
        </div>
        <div class="form-group">
          <input type="email" placeholder="Enter your email" id="mail" name="mail" required="required">
          <label for="mail">
            <i class="fa fa-envelope"></i>
          </label>
        </div>
        <div class="form-group">
          <textarea placeholder="How can we help?" name="text" id="text"></textarea>
          <label for="text" class="txt">
            <i class="fa fa-commenting"></i>
          </label>
        </div>
        <button type="submit" class="main-btn-rect" name="text" value="Send">
          <i class="fa fa-paper-plane"></i>Send</button>
      </form>
    <span class="fade-out main-btn-circle">x</span>
  </div>
</div>      <div class="ftup d-flex al-center">
        <div class="ftlogo"><img src="img/logo.png" alt=""></div>
        <div class="ftup2 popup-btn" data-popup="popup-reg"><button>GET A QUOTE</button></div>
      </div>
      <div class="ftmid d-flex pd-60">
        <div class="ftmenu">
          <p>Quick Links</p>
          <ul>            
            <li><a href="portfolio.php">Portfolio</a></li>            
            <li><a href="mailto:info@digitalinfinityservices.com">Contact Us</a></li>
            <li><a href="tel:(972) 954-2351">Call Now!</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Helpful Links</p>
          <ul>
            <li><a href="privacy.php">Privacy Policy</a></li>
            <li><a href="terms.php">Terms & Conditions</a></li>
          </ul>
        </div>
        <div class="ftmenu">
          <p>Our Socials</p>
          <ul>
            <li><a href="https://www.facebook.com/people/Digital-Infinity-Services/100090365663506/">Facebook</a></li>
            <li><a href="https://www.instagram.com/digitalinfinityservices/">Insta</a></li>
          </ul>
        </div>
      </div>
      <div class="ftend d-flex al-center">
          <div class="ftcopyr"><p>Copyright © 2023 <span>Digital Infinity Services</span>. All Rights Reserved.</p></div>
      </div>
    </footer> 
		<!--  -->
		
	</main>
	<script src="js/main.js"></script>
	<script>
    // ctr
    const counters = document.querySelectorAll('.counter');

counters.forEach(counter =>{
    counter.innerText = '0';

    const updateCounter = () =>{
        const target = +counter.getAttribute('data-target')
        const c = +counter.innerText;

        const increment = target/1000;

        if(c< target){
            counter.innerText = `${Math.ceil(c+increment)}`
            setTimeout(updateCounter,1)
        }else{
            counter.innerText = target
        }
    }
    updateCounter();
})
    // btt
    var btn = $('#topbutton');

$(window).scroll(function() {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '300');
});
	// tbs
	// tabs
	var tabLinks = document.querySelectorAll(".tablinks");
	var tabContent = document.querySelectorAll(".tabcontent");
	tabLinks.forEach(function(el) {
		el.addEventListener("click", openTabs);
	});

	function openTabs(el) {
		var btnTarget = el.currentTarget;
		var country = btnTarget.dataset.country;
		tabContent.forEach(function(el) {
			el.classList.remove("active");
		});
		tabLinks.forEach(function(el) {
			el.classList.remove("active");
		});
		document.querySelector("#" + country).classList.add("active");
		btnTarget.classList.add("active");
	}
	// menu
	$('#toggle').click(function() {
		$(this).toggleClass('active');
		$('#overlay').toggleClass('open');
	});
	jQuery(function($) {
		var html = $('html');
		var viewport = $(window);
		var viewportHeight = viewport.height();
		var scrollMenu = $('#section-menu');
		var timeout = null;

		function menuFreeze() {
			if(timeout !== null) {
				scrollMenu.removeClass('freeze');
				clearTimeout(timeout);
			}
			timeout = setTimeout(function() {
				scrollMenu.addClass('freeze');
			}, 2000);
		}
		scrollMenu.mouseover(menuFreeze);
		/* ==========================================================================
		   Build the Scroll Menu based on Sections .scroll-item
		   ========================================================================== */
		var sectionsHeight = {},
			viewportheight, i = 0;
		var scrollItem = $('.scroll-item');
		var bannerHeight;

		function sectionListen() {
			viewportHeight = viewport.height();
			bannerHeight = (viewportHeight);
			$('.section').addClass('resize');
			scrollItem.each(function() {
				sectionsHeight[this.title] = $(this).offset().top;
			});
		}
		sectionListen();
		viewport.resize(sectionListen);
		viewport.bind('orientationchange', function() {
			sectionListen();
		});
		var count = 0;
		scrollItem.each(function() {
			var anchor = $(this).attr('id');
			var title = $(this).attr('title');
			count++;
			$('#section-menu ul').append('<li><a id="nav_' + title + '" href="#' + anchor + '"><span>' + count + '</span> ' + title + '</a></li>');
		});

		function menuListen() {
			var pos = $(this).scrollTop();
			pos = pos + viewportHeight * 0.625;
			for(i in sectionsHeight) {
				if(sectionsHeight[i] < pos) {
					$('#section-menu a').removeClass('active');
					$('#section-menu a#nav_' + i).addClass('active');;
					var newHash = '#' + $('.scroll-item[title="' + i + '"]').attr('id');
					if(history.pushState) {
						history.pushState(null, null, newHash);
					} else {
						location.hash = newHash;
					}
				} else {
					$('#section-menu a#nav_' + i).removeClass('active');
					if(pos < viewportHeight - 72) {
						history.pushState(null, null, ' ');
					}
				}
			}
		}
		scrollMenu.css('margin-top', scrollMenu.height() / 2 * -1);
		/* ==========================================================================
		   Smooth Scroll for Anchor Links and URL refresh
		   ========================================================================== */
		scrollMenu.find('a').click(function() {
			var href = $.attr(this, 'href');
			$('html').animate({
				scrollTop: $(href).offset().top
			}, 500, function() {
				window.location.hash = href;
			});
			return false;
		});
		/* ==========================================================================
		   Fire functions on Scroll Event
		   ========================================================================== */
		function scrollHandler() {
			menuListen();
			menuFreeze();
		}
		scrollHandler();
		viewport.on('scroll', function() {
			scrollHandler();
			//			window.requestAnimationFrame(scrollHandler);
		});
	});
      $(document).ready(function(){
  $('.popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','0').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 600);
      });
 });
});
	</script>

</body>

</html>